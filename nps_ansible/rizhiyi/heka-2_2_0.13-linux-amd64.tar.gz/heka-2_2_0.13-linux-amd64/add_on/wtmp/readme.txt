监控linux/aix/solaris last输出：
1.将wtmp 文件夹拷贝到 /opt/RZY/unix_scripts 目录下
2.用rizhiyi-agent 监控/opt/RZY/unix_scripts/wtmp/last.log和who.log 文件
3.定时任务
crontab -e 每5分钟运行一次
*/5 * * * * /bin/sh /opt/RZY/unix_scripts/wtmp/last.sh > /dev/null 2>&1
*/5 * * * * /bin/sh /opt/RZY/unix_scripts/wtmp/who.sh > /dev/null 2>&1


监控aix/solaris failedlogin:
1.将wtmp 文件夹拷贝到 /opt/RZY/unix_scripts 目录下
2.用rizhiyi-agent 监控/opt/RZY/unix_scripts/failedlogin/fail.log 文件
3.定时任务
crontab -e 每5分钟运行一次
*/5 * * * * /bin/sh /opt/RZY/unix_scripts/wtmp/failedlogin_unix.sh > /dev/null 2>&1


监控aix /auditlog/trail:
1.将wtmp 文件夹拷贝到 /opt/RZY/unix_scripts 目录下
2.用rizhiyi-agent 监控/opt/RZY/unix_scripts/audit/audit.log 文件
3.定时任务
crontab -e 每5分钟运行一次
*/5 * * * * /bin/sh /opt/RZY/unix_scripts/wtmp/audit_aix.sh > /dev/null 2>&1





统计当天用户登录情况（注意who的数据不需要做时间戳匹配，取agent采集时间）

appname:who | stats count() by who.srchost,who.user,who.login_time|rename who.srchost as host|rename who.user as user|rename who.login_time as login_time |join type=left host,user,login_time [[appname:last | table last.user,last.srchost,timestamp,last.span_m|eval login_time=formatdate(timestamp,"yyyy-MM-dd HH:mm")|rename last.srchost as host|rename last.user as user]] | eval result=if(empty(last.span_m),1,0) | where result>0 | append [[appname:last | table last.user,last.srchost,last.span_d,last.span_h,last.span_m,timestamp|rename last.srchost as host|rename last.user as user|eval login_time=formatdate(timestamp,"yyyy-MM-dd HH:mm")]]|fields host,user,login_time,last.span_d,last.span_h,last.span_m


appname:who | stats count() by who.srchost,who.user,who.login_time|rename who.srchost as host|rename who.user as user|rename who.login_time as login_time |join type=left host,user,login_time [[appname:last | table last.user,last.srchost,timestamp,last.span_m|eval login_time=formatdate(timestamp,"MMM dd HH:mm")|rename last.srchost as host|rename last.user as user]] | eval result=if(empty(last.span_m),1,0) | where result>0 | append [[appname:last | table last.user,last.srchost,last.span_d,last.span_h,last.span_m,timestamp|rename last.srchost as host|rename last.user as user|eval login_time=formatdate(timestamp,"yyyy-MM-dd HH:mm")]]|fields host,user,login_time,last.span_d,last.span_h,last.span_m

日志样例及正则：
linux：
root     pts/0        192.168.1.216    Tue Jan 24 20:03 - 20:04  (1+00:00)	
(?<user>\S+)\s+\S+\s+(?<srchost>\S+)\s+\S+\s+(?<timestamp>\S+\s+\S+\s+\S+:\S+)\s+-.*?\((?<span_d>\d+)\+(?<span_h>\d+)\:(?<span_m>\d+)\)

root     pts/0            Tue Jan 24 20:03 - 20:04  (1+00:00)  	
(?<user>\S+)\s+\S+\s+\S+\s+(?<timestamp>\S+\s+\d+\s+\S+:\S+)\s+-.*?\((?<span_d>\d+)\+(?<span_h>\d+)\:(?<span_m>\d+)\)
root     pts/0        192.168.1.216    Tue Jan 24 20:03 - 20:04  (00:00)	
(?<user>\S+)\s+\S+\s+(?<srchost>\S+)\s+\S+\s+(?<timestamp>\S+\s+\S+\s+\S+:\S+)\s+-.*?\((?<span_h>\d+)\:(?<span_m>\d+)\)
root     pts/0            Tue Jan 24 20:03 - 20:04  (00:00)	
(?<user>\S+)\s+\S+\s+\S+\s+(?<timestamp>\S+\s+\S+\s+\S+:\S+)\s+-.*?\((?<span_h>\d+)\:(?<span_m>\d+)\)


aix：注意aix的天 有些只有一位，没有补0
root      pts/1        192.168.2.156          Aug 15 23:51 - System halted abnormally.  (1+00:19)	
(?<user>\S+)\s+\S+\s+(?<srchost>\S+)\s+(?<timestamp>\S+\s+\S+\s+\S+:\S+)\s+-.*?\((?<span_d>\d+)\+(?<span_h>\d+)\:(?<span_m>\d+)\)
root      vty0                                Sep 01 08:16 - 08:19  (1+00:03)	
(?<user>\S+)\s+\S+\s+(?<timestamp>\S+\s+\S+\s+\S+:\S+)\s+-.*?\((?<span_d>\d+)\+(?<span_h>\d+)\:(?<span_m>\d+)\)

root      pts/0        splunk.yottabyte.cn       Sep 01 19:25 - 20:47  (01:22)
(?<user>\S+)\s+\S+\s+(?<srchost>\S+)\s+(?<timestamp>\S+\s+\S+\s+\S+:\S+)\s+-.*?\((?<span_h>\d+)\:(?<span_m>\d+)\)
root      vty0                                Sep  1 08:16 - 08:19  (00:03)	
(?<user>\S+)\s+\S+\s+(?<timestamp>\S+\s+\S+\s+\S+:\S+)\s+-.*?\((?<span_h>\d+)\:(?<span_m>\d+)\)




