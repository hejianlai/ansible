#!/usr/bin/ksh
BDIR=/opt/RZY/unix_scripts/errpt
iam=`basename $0`
PIDFILE=$BDIR/$iam.pid
#echo "PIDFILE IS: $PIDFILE"
[ -d /opt/RZY/unix_scripts/errpt ] || { mkdir -p /opt/RZY/unix_scripts/errpt; }
ERRPTLOG=$BDIR/rzy_errpt.log
LASTRUN=$BDIR/rzy_errpt_lastrun

for pid in `ps -ef|grep -v grep|awk '/rzy_errpt/ {print $2}'`
do
        echo "Cleaning up old errpt processes: killing $pid"
        /usr/bin/kill -9 $pid
done

sleep 2

nohup /bin/sh $BDIR/errpt.sh &