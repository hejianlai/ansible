#!/bin/bash
BASEDIR=/opt/RZY/unix_scripts/wtmp
AGENTGETFILE=${BASEDIR}/who.log
TEMPFILE=${BASEDIR}/who_temp.log

DATETIME=`date "+%Y-%m-%d %H:%M:%S"`

[[ ! -d ${BASEDIR} ]] && mkdir -p ${BASEDIR}
if [[ ! -d ${BASEDIR} ]];then
  echo "Error: directory ${BASEDIR} creation failed!"
  exit
fi

fileIfExists() {
if [[ ! -f $1 ]];then
  touch $1
fi
}

getFileSize() {
FILESIZE=`ls -l $1 | awk '{print $5}'`
}

fileIfExists ${AGENTGETFILE}
fileIfExists ${TEMPFILE}

who > ${TEMPFILE};sed "s/^/${DATETIME} &/g" ${TEMPFILE} > ${AGENTGETFILE}