#!/usr/bin/ksh
BDIR=/opt/RZY/unix_scripts/errpt
iam=`basename $0`
PIDFILE=$BDIR/$iam.pid
#echo "PIDFILE IS: $PIDFILE"
[ -d /opt/RZY/unix_scripts/errpt ] || { mkdir -p /opt/RZY/unix_scripts/errpt; }
ERRPTLOG=$BDIR/rzy_errpt.log
LASTRUN=$BDIR/rzy_errpt_lastrun

nice_stop()
{
	for pid in `ps -ef|grep -v grep|awk '/rzy_errpt/ {print $2}'`
	do
        	echo "Cleaning up old errpt processes: killing $pid"
        	/usr/bin/kill -9 $pid
	done
        [ -f $PIDFILE ] && { rm $PIDFILE; }
        date +%m%d%H%M%y > $LASTRUN
        exit 0
}

trap "nice_stop" INT TERM SIGHUP SIGINT SIGTERM

watch()
{
        echo "Refreshing PIDFILE"
        echo $$ > $PIDFILE
        echo "Setting lastrun"
        [ -f $LASTRUN ] && { lastrun=`cat $LASTRUN`; } || { lastrun=`date +%m%d%H%M%y`; }
	
	# Test to see if rzy_errpt link exists, else create it
	[ -h $BDIR/rzy_errpt ] || { ln -s /usr/bin/errpt $BDIR/rzy_errpt; }
        echo "starting $BDIR/rzy_errpt -ac -s $lastrun > $ERRPTLOG"
        $BDIR/rzy_errpt -ac -s $lastrun > $ERRPTLOG
        date +%m%d%H%M%y > $LASTRUN
        nice_stop

}

if [ ! -f $ERRPTLOG ];then
        echo 0101010010 > $LASTRUN

if [ -f $PIDFILE ];then
        OLDPID=`cat $PIDFILE`
        if [ `ps -ef|grep -v grep|grep -c $OLDPID` -gt 0 ] || [ `ps -ef|grep -v grep |grep -c "errpt.sh"` -gt 1 ]; then
                echo "$iam Still running"
		exit 1
        else
                [ -f $PIDFILE ] && { rm $PIDFILE; }
		
		# cron task tends to kill scripts with a -9 so errpt doesn't get whacked
		# Now I'm going to kill any remaining
		for pid in `ps -ef|grep -v grep|awk '/rzy_errpt/ {print $2}'`
		do
        		echo "Cleaning up old errpt processes: killing $pid"
        		/usr/bin/kill -9 $pid
		done

                watch
        fi
elif [ `ps -ef|grep -v grep|grep -c rzy_errpt` -gt 0 ]; then	
        for pid in `ps -ef|grep -v grep|awk '/rzy_errpt/ {print $2}'`
        do
                echo "Cleaning up old errpt processes: killing $pid"
                /usr/bin/kill -9 $pid
        done	
else
        watch
fi