#!/bin/bash

BASEDIR=/opt/RZY/unix_scripts/wtmp
AGENTGETFILE=${BASEDIR}/last.log
FILENAME=${BASEDIR}/diff.log
TEMPFILE=${BASEDIR}/temp.log
TEMPLOGFILE=${BASEDIR}/temp1.log
NUM=${1:-100}
THRESHOLDSIZE=${2:-100000000}

[[ ! -d ${BASEDIR} ]] && mkdir -p ${BASEDIR}
if [[ ! -d ${BASEDIR} ]];then
  echo "Error: directory ${BASEDIR} creation failed!"
  exit
fi

fileIfExists() {
if [[ ! -f $1 ]];then
  touch $1
fi
}

getFileSize() {
FILESIZE=`ls -l $1 | awk '{print $5}'`
}

getAllWtmpLog() {
#get all wtmp logs at the first time
if [[ -f $1 && ! -s $1 ]] && [[ -f $2 && ! -s $2 ]];then
last | egrep -v "^$|^wtmp begins|still logged in|^\<reboot\>|^reboot|^shutdown"> $1
cp $1 $2
exit
fi
}

fileIfExists ${FILENAME}
fileIfExists ${AGENTGETFILE}

#If you want to get all wtmp logs at the first time, uncomment below
#getAllWtmpLog ${FILENAME} ${AGENTGETFILE}

getFileSize ${FILENAME}
if [[ ${FILESIZE} -gt ${THRESHOLDSIZE} ]];then
  let HEADNUM=${NUM}+1   #below will add 1 to ${FILENAME} if the file is empty
  head -n ${HEADNUM} ${FILENAME} > ${TEMPLOGFILE}
  tail -n ${NUM} ${FILENAME} >> ${TEMPLOGFILE} && mv ${TEMPLOGFILE} ${FILENAME}
fi
getFileSize ${AGENTGETFILE}
if [[ ${FILESIZE} -gt ${THRESHOLDSIZE} ]];then
  echo > ${AGENTGETFILE}
fi

last -n $NUM | egrep -v "^$|^wtmp begins|still logged in|^\<reboot\>|^reboot|^shutdown"> ${TEMPFILE}
if [[ ! -s ${FILENAME} ]];then
  echo 1 >> ${FILENAME}  #if the file is empty, add 1 to it so that below awk can work
fi
awk 'NR==FNR {a[$0]} NR>FNR && !($0 in a) {print $0}' ${FILENAME} ${TEMPFILE} >> ${AGENTGETFILE}
awk 'NR==FNR {a[$0]} NR>FNR && !($0 in a) {print $0}' ${FILENAME} ${TEMPFILE} >> ${FILENAME}
#comment below because aix awk version is too low to support ARGIND
#awk 'ARGIND==1 {a[$0]} ARGIND>1 && !($0 in a) {print $0}' ${FILENAME} ${TEMPFILE} >> ${AGENTGETFILE}
#awk 'ARGIND==1 {a[$0]} ARGIND>1 && !($0 in a) {print $0}' ${FILENAME} ${TEMPFILE} >> ${FILENAME}
